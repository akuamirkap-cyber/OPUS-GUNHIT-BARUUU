import GameShell from "./GameShell";

/**
 * Perfect Shot v1 (github.com/akuamirkap-cyber/perfectshotv1) – SANS STUDIO intro + GUN HIT SGA –
 * combined with the custom GAME OVER experience (components/GameOverLayer: results V1–V6,
 * x2 reward ads, boss gift R1, weapon collection, coin/diamond fly-in), which replaces the
 * game's own game-over card inside src/games/gunhit/App.tsx.
 */
export default function App() {
  return <GameShell />;
}
