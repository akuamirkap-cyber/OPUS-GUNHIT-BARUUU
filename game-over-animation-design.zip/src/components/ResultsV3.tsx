import Title3D from "./Title3D";
import { Bullet } from "./Target";
import { Coin, Diamond, RetryIcon } from "./Icons";
import { AdTag, MorphMedal, RetryTag } from "./FancyButtons";
import { MiniGift } from "./GiftBox";
import { WEAPONS, WeaponArt } from "./Weapons";
import { NewBestRibbon, Trophy, fmt, type ResultsProps } from "./ResultParts";
import { StatsStrip, useShowcase } from "./ResultsV2";

const POP = "pop .45s cubic-bezier(.2,.9,.3,1.25)";

/** square reward tile – medal pops out of the top edge */
function Tile({
  show,
  delay = 0,
  tone,
  medal,
  title,
  sub,
  sticker,
  stickerBg,
  disabled,
  done,
  onClick,
}: {
  show: boolean;
  delay?: number;
  tone: "purple" | "blue";
  medal: React.ReactNode;
  title: string;
  sub: string;
  sticker: string;
  stickerBg: string;
  disabled: boolean;
  done: string;
  onClick: () => void;
}) {
  return (
    <div className={`relative flex-1 ${show ? "" : "invisible"}`} style={{ animation: show ? `slide-up .5s cubic-bezier(.2,.8,.3,1.1) ${delay}s both` : undefined }}>
      <button
        onClick={onClick}
        disabled={disabled}
        className={`b3d b3d-${tone} h-[84px] w-full`}
        style={{ ["--lip" as string]: "5px", ["--r" as string]: "20px", ["--shine-delay" as string]: tone === "purple" ? "2s" : "3.2s" }}
      >
        <span className="b3d-move pointer-events-none absolute left-1/2 -top-[26px] z-20 block -translate-x-1/2">
          <span className="relative block" style={{ animation: show ? `pop .5s cubic-bezier(.2,.9,.3,1.4) ${delay + 0.2}s both` : undefined }}>
            {medal}
            <span
              className="absolute -bottom-1 -right-3 rotate-[-8deg] rounded-md px-1.5 font-lilita text-[12px] leading-[16px] text-white"
              style={{ background: stickerBg, boxShadow: "0 2px 0 rgba(0,0,0,0.35)", border: "1.5px solid rgba(255,255,255,0.85)" }}
            >
              {sticker}
            </span>
          </span>
        </span>
        <span className="b3d-move b3d-face flex-col justify-end pb-2.5 text-white">
          {disabled ? (
            <span className="relative z-10 font-lilita text-[18px] text-white/85">{done}</span>
          ) : (
            <>
              <span className="lbl-3d relative z-10 font-lilita text-[19px] leading-none">{title}</span>
              <span className="relative z-10 mt-1 font-russo text-[10px] tracking-wide text-white/85">{sub}</span>
            </>
          )}
        </span>
      </button>
      {!disabled && <AdTag className="-right-2 -top-3" />}
    </div>
  );
}

/** V3 – "Focus": one huge RETRY, reward tiles, HOME as a quiet link */
export default function ResultsV3(p: ResultsProps) {
  const { at, intro, skip, rewardRef, gemRef, isNewBest, shots, score, acc, reward, best } = useShowcase(p);
  const aura = WEAPONS[p.gun].aura;

  return (
    <div className="relative flex h-full flex-col items-center px-6 pt-[60px]" onPointerDown={intro ? skip : undefined}>
      {/* title */}
      <div className="relative z-20 w-full" style={{ animation: at("GUN") ? "title-bob 3.2s ease-in-out infinite" : undefined }}>
        <Title3D text="GAME" variant="red" size={62} anim="drop" stagger={70} sound />
        <div className="-mt-2">{at("OVER") ? <Title3D text="OVER" variant="gold" size={70} anim="slam" stagger={55} /> : <div className="h-[66px]" />}</div>
        {at("BULLET") && (
          <div className="pointer-events-none absolute left-0 top-[56px]" style={{ animation: "bullet-across .7s cubic-bezier(.3,.1,.4,1) both" }}>
            <Bullet className="scale-75" />
          </div>
        )}
      </div>

      {/* gun */}
      <div className="relative z-10 flex h-[146px] w-full items-center justify-center">
        {at("GUN") && (
          <>
            <div className="rays anim-rays anim-fade absolute h-[340px] w-[340px] rounded-full opacity-50" />
            <div className="absolute bottom-0 h-6 w-48 rounded-[50%] bg-black/45 blur-md" />
            <div style={{ animation: "gun-in .75s cubic-bezier(.2,.8,.3,1.1) both" }}>
              <div className="anim-float" style={{ filter: aura ? `drop-shadow(0 0 16px ${aura})` : undefined }}>
                <WeaponArt id={p.gun} scale={1.38} tilt={-8} />
              </div>
            </div>
          </>
        )}
      </div>

      {/* score card with built-in reward footer */}
      <div className={`panel relative mt-1 w-full overflow-visible rounded-[24px] ${at("CARD") ? "anim-slide-up" : "invisible"}`}>
        <div className="px-4 pt-3">
          <div className="flex items-center justify-center gap-3">
            <div className="txt-gold font-russo text-[50px] leading-none">{fmt(score)}</div>
          </div>
          <div className="mt-1.5 flex items-center justify-center gap-3 font-russo text-[11px] tracking-[0.25em] text-white/55">
            <span>SCORE</span>
            <span className="h-3 w-px bg-white/20" />
            <span className="flex items-center gap-1 tracking-widest">
              <Trophy size={12} /> BEST
              <span key={best} className={`ml-0.5 inline-block text-[15px] tracking-normal text-white ${at("BEST") && isNewBest ? "anim-pop" : ""}`}>
                {fmt(best)}
              </span>
            </span>
          </div>
          <div className="mt-3">
            <StatsStrip stage={p.stage} hits={p.hits} shots={shots} acc={acc} show={at("STATS")} />
          </div>
        </div>
        {/* footer */}
        <div className={`mt-3 flex h-[46px] items-center justify-center gap-4 rounded-b-[24px] border-t border-white/10 bg-black/25 ${at("REWARD") ? "anim-fade" : "invisible"}`}>
          <span className="font-russo text-[11px] tracking-[0.25em] text-white/55">REWARD</span>
          <div ref={rewardRef} className="flex items-center gap-1.5">
            <Coin size={26} />
            <span className="font-lilita text-[22px] text-[#ffc531]" style={{ textShadow: "0 2px 0 #7a4200" }}>
              +{reward}
            </span>
          </div>
          <span ref={gemRef} className="flex items-center gap-1">
            <Diamond size={22} />
            <span className="font-lilita text-[20px] text-[#bfeaff]" style={{ textShadow: "0 2px 0 #0c4c91" }}>
              +{p.gems}
            </span>
          </span>
        </div>
        {at("BEST") && isNewBest && <NewBestRibbon className="-right-4 -top-4" />}
      </div>

      {/* reward tiles */}
      <div className="mt-[34px] flex w-full gap-3">
        <Tile
          show={at("EXTRA")}
          tone="purple"
          medal={<MorphMedal size={52} />}
          title="x2 REWARD"
          sub="COIN + DIAMOND"
          sticker="x2"
          stickerBg="linear-gradient(180deg,#ff6a4d,#d92a17)"
          disabled={p.doubleUsed}
          done="CLAIMED ✓"
          onClick={p.onDouble}
        />
        <Tile
          show={at("EXTRA")}
          delay={0.08}
          tone="blue"
          medal={
            <span className="medal h-[52px] w-[52px]" style={{ background: "radial-gradient(circle at 35% 30%, #f0e2ff, #b07cff 45%, #6a2fd6)" }}>
              <MiniGift size={32} />
            </span>
          }
          title="KADO BOSS"
          sub="HADIAH MISTERI"
          sticker="R1"
          stickerBg="linear-gradient(180deg,#ffc531,#e08a00)"
          disabled={p.gift !== "new"}
          done="DIBUKA ✓"
          onClick={p.onGift}
        />
      </div>

      {/* hero retry */}
      <div className={`relative mt-[18px] w-full ${at("BUTTONS") ? "" : "invisible"}`} style={{ animation: at("BUTTONS") ? `${POP} 0s both` : undefined }}>
        <div className="pointer-events-none absolute -inset-x-1 -bottom-2 top-2 rounded-[26px] bg-[#3cf266] blur-xl" style={{ animation: "fx-glow-breathe 2.4s ease-in-out infinite" }} />
        <button onClick={p.onRetry} className="b3d b3d-green h-[66px] w-full">
          <span className="b3d-move b3d-face justify-center gap-3 text-white">
            <span className="lbl-3d relative z-10 font-lilita text-[34px] tracking-wide">RETRY</span>
            <span className="b3d-chip relative z-10 h-[42px] w-[42px]">
              <span className="flex" style={{ animation: "spin-pause 3.4s cubic-bezier(.6,0,.3,1) infinite 1.8s" }}>
                <RetryIcon />
              </span>
            </span>
          </span>
        </button>
        <RetryTag className="-right-2 -top-3" />
      </div>

      {/* home link */}
      <button
        onClick={p.onHome}
        className={`mt-2.5 flex items-center gap-1.5 px-4 py-1.5 font-lilita text-[17px] tracking-wide text-white/60 transition hover:text-white ${at("BUTTONS") ? "anim-fade-up" : "invisible"}`}
        style={{ animationDelay: "0.25s" }}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 3 2 11.5h3V21h5.5v-6h3v6H19v-9.5h3z" />
        </svg>
        KEMBALI KE MENU
      </button>
    </div>
  );
}
